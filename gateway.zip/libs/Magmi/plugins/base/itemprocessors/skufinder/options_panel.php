<div class="plugin_description">
This plugins can be used in <b>update</b> mode to find sku from custom column in datasource.
this column <b>MUST</b> be an attribute code
</div>
<ul class="formline">
<li class="label">
 	<span>sku find attribute code</span>
</li>
	<li class="value">
		<input type="text" name="SKUF:matchfield" value="<?php $this->getParam("SKUF:matchfield","")?>">
	</li>
	
</ul>