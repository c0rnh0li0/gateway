<div class="plugin_description">
This plugin automatically trims values for select/multiselect attributes.
</div>
