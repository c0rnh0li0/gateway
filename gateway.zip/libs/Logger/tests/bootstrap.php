<?php

require_once 'PHPUnit/Autoload.php';

require_once __DIR__ . '/../ILogger.php';
require_once __DIR__ . '/../ILoggerFactory.php';
require_once __DIR__ . '/../Logger/AbstractLogger.php';