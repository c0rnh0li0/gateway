<?php

namespace Gateway;

/** 
 * DataSource interface.
 *
 * @author Lukas Bruha
 */
interface IDataSource {
   
}

