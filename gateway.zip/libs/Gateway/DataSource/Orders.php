<?php

namespace Gateway\DataSource;

/**
 * Orders DataSource encapsulating orders data.
 *
 * @author Lukas Bruha
 */
class Orders extends \Gateway\DataSource {
  
}