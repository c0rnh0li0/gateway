<?php

namespace Gateway\DataSource;

/**
 * Customers DataSource encapsulating customers data.
 *
 * @author Lukas Bruha
 */
class Customers extends \Gateway\DataSource {
  
}