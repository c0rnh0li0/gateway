<?php

namespace Gateway\DataSource;

/**
 * Stock DataSource encapsulates stock data.
 *
 * @author Nikola Badev
 */
class Stock extends \Gateway\DataSource {
  
    
}