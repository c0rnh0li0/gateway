<?php

namespace Gateway\DataSource;

/**
 * Products DataSource encapsulates products data.
 *
 * @author Lukas Bruha
 */
class Products extends \Gateway\DataSource {
  
    
}