<?php
namespace Gateway\DataSource\Entity;

/**
 * Customer interface.
 * 
 * @author Lukas Bruha
 */
interface ICustomer {
 
       
}
