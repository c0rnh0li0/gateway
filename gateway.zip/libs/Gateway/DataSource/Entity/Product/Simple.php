<?php

namespace Gateway\DataSource\Entity\Product;

/**
 * Simple product entity.
 *
 * @author Lukas Bruha
 */
class Simple extends \Gateway\DataSource\Entity\Product {

    protected $type = self::TYPE_SIMPLE;

}

