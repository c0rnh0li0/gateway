<?php

namespace Gateway\DataSource\Entity\Product;

/**
 * Bundle product entity.
 *
 * @author Lukas Bruha
 */
class Bundle extends Complex {
    
    protected $type = self::TYPE_BUNDLE;
    
}

