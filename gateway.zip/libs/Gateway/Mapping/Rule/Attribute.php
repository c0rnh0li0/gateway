<?php

namespace Gateway\Mapping\Rule;

use Gateway\Mapping\Rule;

/**
 * Attribute mapping rule.
 *
 * @author Lukas Bruha
 */
class Attribute extends Rule {
   
    protected $type = self::TYPE_ATTRIBUTE;
    
}
